-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 26, 2023 at 03:52 PM
-- Server version: 10.6.12-MariaDB-cll-lve
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u452657014_crm`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `activity_type_id` bigint(20) UNSIGNED DEFAULT NULL,
  `contextable_type` varchar(191) DEFAULT NULL,
  `contextable_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `status_id` bigint(20) UNSIGNED DEFAULT NULL,
  `started_at` date DEFAULT NULL,
  `ended_at` date DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `reminder_on` timestamp NULL DEFAULT NULL,
  `reminder_type` varchar(191) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `activity_collaborator`
--

CREATE TABLE `activity_collaborator` (
  `activity_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `log_name` varchar(160) DEFAULT NULL,
  `description` text NOT NULL,
  `subject_id` bigint(20) UNSIGNED DEFAULT NULL,
  `subject_type` varchar(160) DEFAULT NULL,
  `causer_id` bigint(20) UNSIGNED DEFAULT NULL,
  `causer_type` varchar(160) DEFAULT NULL,
  `properties` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`id`, `log_name`, `description`, `subject_id`, `subject_type`, `causer_id`, `causer_type`, `properties`, `created_at`, `updated_at`) VALUES
(1, 'default', 'User has been Created', 1, 'Gainhq\\Installer\\App\\Models\\Core\\User', NULL, NULL, '{\"attributes\":{\"first_name\":\"Super\",\"last_name\":\"Admin\",\"email\":\"admin@admin.com\"}}', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(2, 'default', 'Notification Setting has been Created', 1, 'App\\Models\\Core\\Setting\\NotificationSetting', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(3, 'default', 'created', 1, 'App\\Models\\Core\\Setting\\NotificationAudience', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(4, 'default', 'Notification Setting has been Created', 2, 'App\\Models\\Core\\Setting\\NotificationSetting', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(5, 'default', 'created', 2, 'App\\Models\\Core\\Setting\\NotificationAudience', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(6, 'default', 'Notification Setting has been Created', 3, 'App\\Models\\Core\\Setting\\NotificationSetting', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(7, 'default', 'created', 3, 'App\\Models\\Core\\Setting\\NotificationAudience', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(8, 'default', 'Notification Setting has been Created', 4, 'App\\Models\\Core\\Setting\\NotificationSetting', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(9, 'default', 'created', 4, 'App\\Models\\Core\\Setting\\NotificationAudience', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(10, 'default', 'Notification Setting has been Created', 5, 'App\\Models\\Core\\Setting\\NotificationSetting', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(11, 'default', 'created', 5, 'App\\Models\\Core\\Setting\\NotificationAudience', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(12, 'default', 'Notification Setting has been Created', 6, 'App\\Models\\Core\\Setting\\NotificationSetting', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(13, 'default', 'created', 6, 'App\\Models\\Core\\Setting\\NotificationAudience', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(14, 'default', 'Notification Setting has been Created', 7, 'App\\Models\\Core\\Setting\\NotificationSetting', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(15, 'default', 'created', 7, 'App\\Models\\Core\\Setting\\NotificationAudience', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(16, 'default', 'Notification Setting has been Created', 8, 'App\\Models\\Core\\Setting\\NotificationSetting', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(17, 'default', 'created', 8, 'App\\Models\\Core\\Setting\\NotificationAudience', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(18, 'default', 'Notification Setting has been Created', 9, 'App\\Models\\Core\\Setting\\NotificationSetting', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(19, 'default', 'created', 9, 'App\\Models\\Core\\Setting\\NotificationAudience', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(20, 'default', 'Notification Setting has been Created', 10, 'App\\Models\\Core\\Setting\\NotificationSetting', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(21, 'default', 'created', 10, 'App\\Models\\Core\\Setting\\NotificationAudience', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(22, 'default', 'Notification Setting has been Created', 11, 'App\\Models\\Core\\Setting\\NotificationSetting', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(23, 'default', 'created', 11, 'App\\Models\\Core\\Setting\\NotificationAudience', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(24, 'default', 'Notification Setting has been Created', 12, 'App\\Models\\Core\\Setting\\NotificationSetting', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(25, 'default', 'created', 12, 'App\\Models\\Core\\Setting\\NotificationAudience', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(26, 'default', 'Notification Setting has been Created', 13, 'App\\Models\\Core\\Setting\\NotificationSetting', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(27, 'default', 'created', 13, 'App\\Models\\Core\\Setting\\NotificationAudience', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(28, 'default', 'Notification Setting has been Created', 14, 'App\\Models\\Core\\Setting\\NotificationSetting', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(29, 'default', 'created', 14, 'App\\Models\\Core\\Setting\\NotificationAudience', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(30, 'default', 'Notification template has been Created', 1, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(31, 'default', 'Notification template has been Created', 2, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(32, 'default', 'Notification template has been Created', 3, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(33, 'default', 'Notification template has been Created', 4, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(34, 'default', 'Notification template has been Created', 5, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(35, 'default', 'Notification template has been Created', 6, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(36, 'default', 'Notification template has been Created', 7, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(37, 'default', 'Notification template has been Created', 8, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(38, 'default', 'Notification template has been Created', 9, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(39, 'default', 'Notification template has been Created', 10, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(40, 'default', 'Notification template has been Created', 11, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(41, 'default', 'Notification template has been Created', 12, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(42, 'default', 'Notification template has been Created', 13, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(43, 'default', 'Notification template has been Created', 14, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(44, 'default', 'Notification template has been Created', 15, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(45, 'default', 'Notification template has been Created', 16, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(46, 'default', 'Notification template has been Created', 17, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(47, 'default', 'Notification template has been Created', 18, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(48, 'default', 'Notification template has been Created', 19, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(49, 'default', 'Notification template has been Created', 20, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(50, 'default', 'Notification template has been Created', 21, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(51, 'default', 'Notification template has been Created', 22, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(52, 'default', 'Notification template has been Created', 23, 'App\\Models\\Core\\Notification\\NotificationTemplate', NULL, NULL, '[]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(53, 'default', 'Setting has been updated', 2, 'App\\Models\\Core\\Setting\\Setting', 1, 'App\\Models\\Core\\Auth\\User', '{\"attributes\":[],\"old\":[]}', '2023-05-23 21:25:49', '2023-05-23 21:25:49'),
(54, 'default', 'Setting has been updated', 9, 'App\\Models\\Core\\Setting\\Setting', 1, 'App\\Models\\Core\\Auth\\User', '{\"attributes\":[],\"old\":[]}', '2023-05-23 21:25:49', '2023-05-23 21:25:49'),
(55, 'default', 'Setting has been updated', 3, 'App\\Models\\Core\\Setting\\Setting', 1, 'App\\Models\\Core\\Auth\\User', '{\"attributes\":[],\"old\":[]}', '2023-05-23 21:25:49', '2023-05-23 21:25:49'),
(56, 'default', 'Setting has been updated', 4, 'App\\Models\\Core\\Setting\\Setting', 1, 'App\\Models\\Core\\Auth\\User', '{\"attributes\":[],\"old\":[]}', '2023-05-23 21:25:49', '2023-05-23 21:25:49');

-- --------------------------------------------------------

--
-- Table structure for table `activity_participant`
--

CREATE TABLE `activity_participant` (
  `activity_id` bigint(20) UNSIGNED NOT NULL,
  `person_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `activity_types`
--

CREATE TABLE `activity_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `icon` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activity_types`
--

INSERT INTO `activity_types` (`id`, `name`, `icon`, `created_at`, `updated_at`) VALUES
(1, 'Call', 'phone-call', NULL, NULL),
(2, 'Meeting', 'users', NULL, NULL),
(3, 'Email', 'mail', NULL, NULL),
(4, 'Task', 'credit-card', NULL, NULL),
(5, 'Deadline', 'calendar', NULL, NULL),
(6, 'Others', 'cpu', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(120) NOT NULL,
  `value` text NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contact_types`
--

CREATE TABLE `contact_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `class` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact_types`
--

INSERT INTO `contact_types` (`id`, `name`, `class`, `created_at`, `updated_at`) VALUES
(1, 'Customer', 'success', NULL, NULL),
(2, 'Hot Lead', 'danger', NULL, NULL),
(3, 'Warm Lead', 'purple', NULL, NULL),
(4, 'Cold Lead', 'warning', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(191) NOT NULL,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `code`, `name`, `created_at`, `updated_at`) VALUES
(1, 'AF', 'Afghanistan', NULL, NULL),
(2, 'AX', 'Åland Islands', NULL, NULL),
(3, 'AL', 'Albania', NULL, NULL),
(4, 'DZ', 'Algeria', NULL, NULL),
(5, 'AS', 'American Samoa', NULL, NULL),
(6, 'AD', 'AndorrA', NULL, NULL),
(7, 'AO', 'Angola', NULL, NULL),
(8, 'AI', 'Anguilla', NULL, NULL),
(9, 'AQ', 'Antarctica', NULL, NULL),
(10, 'AG', 'Antigua and Barbuda', NULL, NULL),
(11, 'AR', 'Argentina', NULL, NULL),
(12, 'AM', 'Armenia', NULL, NULL),
(13, 'AW', 'Aruba', NULL, NULL),
(14, 'AU', 'Australia', NULL, NULL),
(15, 'AT', 'Austria', NULL, NULL),
(16, 'AZ', 'Azerbaijan', NULL, NULL),
(17, 'BS', 'Bahamas', NULL, NULL),
(18, 'BH', 'Bahrain', NULL, NULL),
(19, 'BD', 'Bangladesh', NULL, NULL),
(20, 'BB', 'Barbados', NULL, NULL),
(21, 'BY', 'Belarus', NULL, NULL),
(22, 'BE', 'Belgium', NULL, NULL),
(23, 'BZ', 'Belize', NULL, NULL),
(24, 'BJ', 'Benin', NULL, NULL),
(25, 'BM', 'Bermuda', NULL, NULL),
(26, 'BT', 'Bhutan', NULL, NULL),
(27, 'BO', 'Bolivia', NULL, NULL),
(28, 'BA', 'Bosnia and Herzegovina', NULL, NULL),
(29, 'BW', 'Botswana', NULL, NULL),
(30, 'BV', 'Bouvet Island', NULL, NULL),
(31, 'BR', 'Brazil', NULL, NULL),
(32, 'IO', 'British Indian Ocean Territory', NULL, NULL),
(33, 'BN', 'Brunei Darussalam', NULL, NULL),
(34, 'BG', 'Bulgaria', NULL, NULL),
(35, 'BF', 'Burkina Faso', NULL, NULL),
(36, 'BI', 'Burundi', NULL, NULL),
(37, 'KH', 'Cambodia', NULL, NULL),
(38, 'CM', 'Cameroon', NULL, NULL),
(39, 'CA', 'Canada', NULL, NULL),
(40, 'CV', 'Cape Verde', NULL, NULL),
(41, 'KY', 'Cayman Islands', NULL, NULL),
(42, 'CF', 'Central African Republic', NULL, NULL),
(43, 'TD', 'Chad', NULL, NULL),
(44, 'CL', 'Chile', NULL, NULL),
(45, 'CN', 'China', NULL, NULL),
(46, 'CX', 'Christmas Island', NULL, NULL),
(47, 'CC', 'Cocos (Keeling) Islands', NULL, NULL),
(48, 'CO', 'Colombia', NULL, NULL),
(49, 'KM', 'Comoros', NULL, NULL),
(50, 'CG', 'Congo', NULL, NULL),
(51, 'CD', 'Congo, The Democratic Republic of the', NULL, NULL),
(52, 'CK', 'Cook Islands', NULL, NULL),
(53, 'CR', 'Costa Rica', NULL, NULL),
(54, 'CI', 'Cote D\'Ivoire', NULL, NULL),
(55, 'HR', 'Croatia', NULL, NULL),
(56, 'CU', 'Cuba', NULL, NULL),
(57, 'CY', 'Cyprus', NULL, NULL),
(58, 'CZ', 'Czech Republic', NULL, NULL),
(59, 'DK', 'Denmark', NULL, NULL),
(60, 'DJ', 'Djibouti', NULL, NULL),
(61, 'DM', 'Dominica', NULL, NULL),
(62, 'DO', 'Dominican Republic', NULL, NULL),
(63, 'EC', 'Ecuador', NULL, NULL),
(64, 'EG', 'Egypt', NULL, NULL),
(65, 'SV', 'El Salvador', NULL, NULL),
(66, 'GQ', 'Equatorial Guinea', NULL, NULL),
(67, 'ER', 'Eritrea', NULL, NULL),
(68, 'EE', 'Estonia', NULL, NULL),
(69, 'ET', 'Ethiopia', NULL, NULL),
(70, 'FK', 'Falkland Islands (Malvinas)', NULL, NULL),
(71, 'FO', 'Faroe Islands', NULL, NULL),
(72, 'FJ', 'Fiji', NULL, NULL),
(73, 'FI', 'Finland', NULL, NULL),
(74, 'FR', 'France', NULL, NULL),
(75, 'GF', 'French Guiana', NULL, NULL),
(76, 'PF', 'French Polynesia', NULL, NULL),
(77, 'TF', 'French Southern Territories', NULL, NULL),
(78, 'GA', 'Gabon', NULL, NULL),
(79, 'GM', 'Gambia', NULL, NULL),
(80, 'GE', 'Georgia', NULL, NULL),
(81, 'DE', 'Germany', NULL, NULL),
(82, 'GH', 'Ghana', NULL, NULL),
(83, 'GI', 'Gibraltar', NULL, NULL),
(84, 'GR', 'Greece', NULL, NULL),
(85, 'GL', 'Greenland', NULL, NULL),
(86, 'GD', 'Grenada', NULL, NULL),
(87, 'GP', 'Guadeloupe', NULL, NULL),
(88, 'GU', 'Guam', NULL, NULL),
(89, 'GT', 'Guatemala', NULL, NULL),
(90, 'GG', 'Guernsey', NULL, NULL),
(91, 'GN', 'Guinea', NULL, NULL),
(92, 'GW', 'Guinea-Bissau', NULL, NULL),
(93, 'GY', 'Guyana', NULL, NULL),
(94, 'HT', 'Haiti', NULL, NULL),
(95, 'HM', 'Heard Island and Mcdonald Islands', NULL, NULL),
(96, 'VA', 'Holy See (Vatican City State)', NULL, NULL),
(97, 'HN', 'Honduras', NULL, NULL),
(98, 'HK', 'Hong Kong', NULL, NULL),
(99, 'HU', 'Hungary', NULL, NULL),
(100, 'IS', 'Iceland', NULL, NULL),
(101, 'IN', 'India', NULL, NULL),
(102, 'ID', 'Indonesia', NULL, NULL),
(103, 'IR', 'Iran, Islamic Republic Of', NULL, NULL),
(104, 'IQ', 'Iraq', NULL, NULL),
(105, 'IE', 'Ireland', NULL, NULL),
(106, 'IM', 'Isle of Man', NULL, NULL),
(107, 'IL', 'Israel', NULL, NULL),
(108, 'IT', 'Italy', NULL, NULL),
(109, 'JM', 'Jamaica', NULL, NULL),
(110, 'JP', 'Japan', NULL, NULL),
(111, 'JE', 'Jersey', NULL, NULL),
(112, 'JO', 'Jordan', NULL, NULL),
(113, 'KZ', 'Kazakhstan', NULL, NULL),
(114, 'KE', 'Kenya', NULL, NULL),
(115, 'KI', 'Kiribati', NULL, NULL),
(116, 'KP', 'Korea, Democratic People\'S Republic of', NULL, NULL),
(117, 'KR', 'Korea, Republic of', NULL, NULL),
(118, 'KW', 'Kuwait', NULL, NULL),
(119, 'KG', 'Kyrgyzstan', NULL, NULL),
(120, 'LA', 'Lao People\'S Democratic Republic', NULL, NULL),
(121, 'LV', 'Latvia', NULL, NULL),
(122, 'LB', 'Lebanon', NULL, NULL),
(123, 'LS', 'Lesotho', NULL, NULL),
(124, 'LR', 'Liberia', NULL, NULL),
(125, 'LY', 'Libyan Arab Jamahiriya', NULL, NULL),
(126, 'LI', 'Liechtenstein', NULL, NULL),
(127, 'LT', 'Lithuania', NULL, NULL),
(128, 'LU', 'Luxembourg', NULL, NULL),
(129, 'MO', 'Macao', NULL, NULL),
(130, 'MK', 'Macedonia, The Former Yugoslav Republic of', NULL, NULL),
(131, 'MG', 'Madagascar', NULL, NULL),
(132, 'MW', 'Malawi', NULL, NULL),
(133, 'MY', 'Malaysia', NULL, NULL),
(134, 'MV', 'Maldives', NULL, NULL),
(135, 'ML', 'Mali', NULL, NULL),
(136, 'MT', 'Malta', NULL, NULL),
(137, 'MH', 'Marshall Islands', NULL, NULL),
(138, 'MQ', 'Martinique', NULL, NULL),
(139, 'MR', 'Mauritania', NULL, NULL),
(140, 'MU', 'Mauritius', NULL, NULL),
(141, 'YT', 'Mayotte', NULL, NULL),
(142, 'MX', 'Mexico', NULL, NULL),
(143, 'FM', 'Micronesia, Federated States of', NULL, NULL),
(144, 'MD', 'Moldova, Republic of', NULL, NULL),
(145, 'MC', 'Monaco', NULL, NULL),
(146, 'MN', 'Mongolia', NULL, NULL),
(147, 'MS', 'Montserrat', NULL, NULL),
(148, 'MA', 'Morocco', NULL, NULL),
(149, 'MZ', 'Mozambique', NULL, NULL),
(150, 'MM', 'Myanmar', NULL, NULL),
(151, 'NA', 'Namibia', NULL, NULL),
(152, 'NR', 'Nauru', NULL, NULL),
(153, 'NP', 'Nepal', NULL, NULL),
(154, 'NL', 'Netherlands', NULL, NULL),
(155, 'AN', 'Netherlands Antilles', NULL, NULL),
(156, 'NC', 'New Caledonia', NULL, NULL),
(157, 'NZ', 'New Zealand', NULL, NULL),
(158, 'NI', 'Nicaragua', NULL, NULL),
(159, 'NE', 'Niger', NULL, NULL),
(160, 'NG', 'Nigeria', NULL, NULL),
(161, 'NU', 'Niue', NULL, NULL),
(162, 'NF', 'Norfolk Island', NULL, NULL),
(163, 'MP', 'Northern Mariana Islands', NULL, NULL),
(164, 'NO', 'Norway', NULL, NULL),
(165, 'OM', 'Oman', NULL, NULL),
(166, 'PK', 'Pakistan', NULL, NULL),
(167, 'PW', 'Palau', NULL, NULL),
(168, 'PS', 'Palestinian Territory, Occupied', NULL, NULL),
(169, 'PA', 'Panama', NULL, NULL),
(170, 'PG', 'Papua New Guinea', NULL, NULL),
(171, 'PY', 'Paraguay', NULL, NULL),
(172, 'PE', 'Peru', NULL, NULL),
(173, 'PH', 'Philippines', NULL, NULL),
(174, 'PN', 'Pitcairn', NULL, NULL),
(175, 'PL', 'Poland', NULL, NULL),
(176, 'PT', 'Portugal', NULL, NULL),
(177, 'PR', 'Puerto Rico', NULL, NULL),
(178, 'QA', 'Qatar', NULL, NULL),
(179, 'RE', 'Reunion', NULL, NULL),
(180, 'RO', 'Romania', NULL, NULL),
(181, 'RU', 'Russian Federation', NULL, NULL),
(182, 'RW', 'RWANDA', NULL, NULL),
(183, 'SH', 'Saint Helena', NULL, NULL),
(184, 'KN', 'Saint Kitts and Nevis', NULL, NULL),
(185, 'LC', 'Saint Lucia', NULL, NULL),
(186, 'PM', 'Saint Pierre and Miquelon', NULL, NULL),
(187, 'VC', 'Saint Vincent and the Grenadines', NULL, NULL),
(188, 'WS', 'Samoa', NULL, NULL),
(189, 'SM', 'San Marino', NULL, NULL),
(190, 'ST', 'Sao Tome and Principe', NULL, NULL),
(191, 'SA', 'Saudi Arabia', NULL, NULL),
(192, 'SN', 'Senegal', NULL, NULL),
(193, 'CS', 'Serbia and Montenegro', NULL, NULL),
(194, 'SC', 'Seychelles', NULL, NULL),
(195, 'SL', 'Sierra Leone', NULL, NULL),
(196, 'SG', 'Singapore', NULL, NULL),
(197, 'SK', 'Slovakia', NULL, NULL),
(198, 'SI', 'Slovenia', NULL, NULL),
(199, 'SB', 'Solomon Islands', NULL, NULL),
(200, 'SO', 'Somalia', NULL, NULL),
(201, 'ZA', 'South Africa', NULL, NULL),
(202, 'GS', 'South Georgia and the South Sandwich Islands', NULL, NULL),
(203, 'ES', 'Spain', NULL, NULL),
(204, 'LK', 'Sri Lanka', NULL, NULL),
(205, 'SD', 'Sudan', NULL, NULL),
(206, 'SR', 'Suriname', NULL, NULL),
(207, 'SJ', 'Svalbard and Jan Mayen', NULL, NULL),
(208, 'SZ', 'Swaziland', NULL, NULL),
(209, 'SE', 'Sweden', NULL, NULL),
(210, 'CH', 'Switzerland', NULL, NULL),
(211, 'SY', 'Syrian Arab Republic', NULL, NULL),
(212, 'TW', 'Taiwan, Province of China', NULL, NULL),
(213, 'TJ', 'Tajikistan', NULL, NULL),
(214, 'TZ', 'Tanzania, United Republic of', NULL, NULL),
(215, 'TH', 'Thailand', NULL, NULL),
(216, 'TL', 'Timor-Leste', NULL, NULL),
(217, 'TG', 'Togo', NULL, NULL),
(218, 'TK', 'Tokelau', NULL, NULL),
(219, 'TO', 'Tonga', NULL, NULL),
(220, 'TT', 'Trinidad and Tobago', NULL, NULL),
(221, 'TN', 'Tunisia', NULL, NULL),
(222, 'TR', 'Turkey', NULL, NULL),
(223, 'TM', 'Turkmenistan', NULL, NULL),
(224, 'TC', 'Turks and Caicos Islands', NULL, NULL),
(225, 'TV', 'Tuvalu', NULL, NULL),
(226, 'UG', 'Uganda', NULL, NULL),
(227, 'UA', 'Ukraine', NULL, NULL),
(228, 'AE', 'United Arab Emirates', NULL, NULL),
(229, 'GB', 'United Kingdom', NULL, NULL),
(230, 'US', 'United States', NULL, NULL),
(231, 'UM', 'United States Minor Outlying Islands', NULL, NULL),
(232, 'UY', 'Uruguay', NULL, NULL),
(233, 'UZ', 'Uzbekistan', NULL, NULL),
(234, 'VU', 'Vanuatu', NULL, NULL),
(235, 'VE', 'Venezuela', NULL, NULL),
(236, 'VN', 'Viet Nam', NULL, NULL),
(237, 'VG', 'Virgin Islands, British', NULL, NULL),
(238, 'VI', 'Virgin Islands, U.S.', NULL, NULL),
(239, 'WF', 'Wallis and Futuna', NULL, NULL),
(240, 'EH', 'Western Sahara', NULL, NULL),
(241, 'YE', 'Yemen', NULL, NULL),
(242, 'ZM', 'Zambia', NULL, NULL),
(243, 'ZW', 'Zimbabwe', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `custom_fields`
--

CREATE TABLE `custom_fields` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `custom_field_type_id` bigint(20) UNSIGNED NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `context` varchar(191) NOT NULL,
  `meta` text DEFAULT NULL,
  `in_list` tinyint(1) NOT NULL DEFAULT 0,
  `is_for_admin` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `custom_field_types`
--

CREATE TABLE `custom_field_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `custom_field_types`
--

INSERT INTO `custom_field_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'text', NULL, NULL),
(2, 'textarea', NULL, NULL),
(3, 'radio', NULL, NULL),
(4, 'select', NULL, NULL),
(5, 'date', NULL, NULL),
(6, 'number', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `custom_field_values`
--

CREATE TABLE `custom_field_values` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `value` text NOT NULL,
  `contextable_type` varchar(191) NOT NULL,
  `contextable_id` varchar(191) NOT NULL,
  `custom_field_id` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deals`
--

CREATE TABLE `deals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(191) NOT NULL,
  `value` bigint(20) NOT NULL DEFAULT 0,
  `pipeline_id` bigint(20) UNSIGNED NOT NULL,
  `stage_id` bigint(20) UNSIGNED NOT NULL,
  `contextable_type` varchar(191) NOT NULL,
  `contextable_id` bigint(20) NOT NULL,
  `lost_reason_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `owner_id` bigint(20) UNSIGNED DEFAULT NULL,
  `description` text DEFAULT NULL,
  `expired_at` datetime DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `lost_comment` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `histories` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deal_people`
--

CREATE TABLE `deal_people` (
  `deal_id` bigint(20) UNSIGNED NOT NULL,
  `person_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `default_stages`
--

CREATE TABLE `default_stages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `probability` int(11) DEFAULT 100,
  `priority` int(11) NOT NULL DEFAULT 0,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `default_stages`
--

INSERT INTO `default_stages` (`id`, `name`, `probability`, `priority`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'Lead generation', 100, 0, 1, NULL, NULL),
(2, 'Lead nurturing', 100, 1, 1, NULL, NULL),
(3, 'Marketing qualified lead', 100, 2, 1, NULL, NULL),
(4, 'Sales accepted lead', 100, 3, 1, NULL, NULL),
(5, 'Sales qualified lead', 100, 4, 1, NULL, NULL),
(6, 'Closed deal', 100, 4, 1, NULL, NULL),
(7, 'Post-sale', 100, 4, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `discussions`
--

CREATE TABLE `discussions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `commentable_type` varchar(191) DEFAULT NULL,
  `commentable_id` bigint(20) UNSIGNED DEFAULT NULL,
  `comment_body` longtext NOT NULL,
  `commented_by` bigint(20) UNSIGNED DEFAULT NULL,
  `comment_id_of_reply` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `emails`
--

CREATE TABLE `emails` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `value` varchar(191) NOT NULL,
  `type_id` bigint(20) UNSIGNED DEFAULT NULL,
  `contextable_type` varchar(191) DEFAULT NULL,
  `contextable_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `status_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `contact_type_id` bigint(20) UNSIGNED DEFAULT NULL,
  `contextable_type` varchar(191) NOT NULL,
  `contextable_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `expense_area_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `amount` double NOT NULL,
  `description` text DEFAULT NULL,
  `expense_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `expense_areas`
--

CREATE TABLE `expense_areas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `extended_notifications`
--

CREATE TABLE `extended_notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `contextable_type` varchar(191) NOT NULL,
  `contextable_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `audience` varchar(191) NOT NULL,
  `message` longtext DEFAULT NULL,
  `readers_id` varchar(191) NOT NULL DEFAULT '0',
  `read_at` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `path` text NOT NULL,
  `fileable_type` varchar(160) NOT NULL,
  `fileable_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `followers`
--

CREATE TABLE `followers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `person_id` bigint(20) UNSIGNED NOT NULL,
  `contextable_type` varchar(191) NOT NULL,
  `contextable_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `invoice_number` text DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `price` double(16,2) DEFAULT 0.00,
  `total` double(16,2) DEFAULT 0.00,
  `discount_type` varchar(191) DEFAULT NULL,
  `discount_amount` double(16,2) DEFAULT 0.00,
  `issue_date` datetime DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `deal_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status_id` bigint(20) UNSIGNED DEFAULT NULL,
  `owner_id` bigint(20) UNSIGNED DEFAULT NULL,
  `tax_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `note` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(160) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lost_reasons`
--

CREATE TABLE `lost_reasons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `lost_reason` varchar(191) NOT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lost_reasons`
--

INSERT INTO `lost_reasons` (`id`, `lost_reason`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'Miscommunication', 1, NULL, NULL),
(2, 'Price Quotation', 1, NULL, NULL),
(3, 'Proposal Failed', 1, NULL, NULL),
(4, 'Lack of performance', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2013_02_09_0000_create_types_table', 1),
(2, '2013_02_10_072424_create_statuses_table', 1),
(3, '2013_04_09_062329_create_revisions_table', 1),
(4, '2014_10_12_000000_create_users_table', 1),
(5, '2014_10_12_100000_create_password_resets_table', 1),
(6, '2017_09_03_144628_create_permission_tables', 1),
(7, '2017_09_04_064802_create_role_user_table', 1),
(8, '2017_09_26_140332_create_cache_table', 1),
(9, '2017_09_26_140528_create_sessions_table', 1),
(10, '2017_09_26_140609_create_jobs_table', 1),
(11, '2018_04_08_033256_create_password_histories_table', 1),
(12, '2019_08_19_000000_create_failed_jobs_table', 1),
(13, '2020_02_10_071640_create_settings_table', 1),
(14, '2020_02_11_083419_create_custom_field_types_table', 1),
(15, '2020_02_11_083437_create_custom_fields_table', 1),
(16, '2020_02_11_083711_create_custom_field_values_table', 1),
(17, '2020_02_12_123449_create_notification_events_table', 1),
(18, '2020_02_12_123727_create_notification_settings_table', 1),
(19, '2020_02_12_124416_create_notification_channels_table', 1),
(20, '2020_02_12_124533_create_notification_audiences_table', 1),
(21, '2020_02_18_141948_create_notifications_table', 1),
(22, '2020_02_19_092540_create_activity_log_table', 1),
(23, '2020_02_26_112625_create_files_table', 1),
(24, '2020_03_10_124422_create_notification_templates_table', 1),
(25, '2020_03_10_124437_create_notification_event_template_table', 1),
(26, '2020_04_05_111843_create_default_stages_table', 1),
(27, '2020_04_06_082113_create_lost_reasons_table', 1),
(28, '2020_04_06_083017_create_pipelines_table', 1),
(29, '2020_04_06_083154_create_stages_table', 1),
(30, '2020_04_06_111843_create_deals_table', 1),
(31, '2020_04_06_135521_create_phones_table', 1),
(32, '2020_04_06_140517_create_emails_table', 1),
(33, '2020_04_07_074847_create_people_table', 1),
(34, '2020_04_07_081733_create_organizations_table', 1),
(35, '2020_04_07_102315_create_contact_types_table', 1),
(36, '2020_04_07_110510_create_notes_table', 1),
(37, '2020_04_07_124241_create_followers_table', 1),
(38, '2020_04_07_133454_create_events_table', 1),
(39, '2020_04_08_132923_create_participants_table', 1),
(40, '2020_04_08_134839_create_activity_types_table', 1),
(41, '2020_04_08_145905_create_activities_table', 1),
(42, '2020_04_19_081503_create_tags_table', 1),
(43, '2020_05_03_091140_create_profile_table', 1),
(44, '2020_05_11_055249_create_proposals_table', 1),
(45, '2020_05_11_064344_create_person_organization_table', 1),
(46, '2020_06_09_111344_create_phone_email_types_table', 1),
(47, '2020_06_09_134731_create_templates_table', 1),
(48, '2020_07_21_101701_create_activity_participant_table', 1),
(49, '2020_07_21_104839_create_activity_collaborator_table', 1),
(50, '2020_07_28_121743_add_histories_to_deals_table', 1),
(51, '2020_09_16_073832_create_user_social_profile_links_table', 1),
(52, '2020_10_13_185351_create_taggable_table', 1),
(53, '2020_12_22_115306_create_countries_table', 1),
(54, '2020_12_23_101004_add_address_related_columns_in_people_table', 1),
(55, '2020_12_23_113948_add_address_related_columns_in_organization_table', 1),
(56, '2021_01_25_061137_add_contextable_morph_column_in_deals_table', 1),
(57, '2021_01_25_061359_move_org_person_col_data_to_contextable_morph_column_in_deals_table', 1),
(58, '2021_01_25_061441_delete_org_person_col_in_deals_table', 1),
(59, '2021_01_25_065607_create_deal_people_table', 1),
(60, '2021_04_06_093801_add_description_in_deals_table', 1),
(61, '2021_04_27_082558_create_add_user_id_in_people_table', 1),
(62, '2021_05_11_092656_create_discussions_table', 1),
(63, '2021_06_02_051856_create_extended_notifications_table', 1),
(64, '2021_06_13_094342_add_row_insert_to_permissions_table', 1),
(65, '2021_06_14_124301_add_row_insert_to_notification_events_table', 1),
(66, '2021_06_15_080023_add_row_insert_to_role_permission_role_table', 1),
(67, '2021_06_15_093534_add_row_insert_to_status_table', 1),
(68, '2021_06_16_102148_add_row_update_to_permissions_table', 1),
(69, '2021_06_16_110225_add_row_delete_to_permissions_table', 1),
(70, '2021_10_26_064018_create_table_filters_table', 1),
(71, '2021_11_22_104741_add_title_field_in_notes_table', 1),
(72, '2022_03_20_061911_create_invoices_table', 1),
(73, '2022_08_28_103355_add_reminder_on_activities_table', 1),
(74, '2023_02_13_063707_create_taxes_table', 1),
(75, '2023_02_13_133811_add_tax_id_to_invoce', 1),
(76, '2023_03_01_132034_create_expense_areas_table', 1),
(77, '2023_03_01_132705_create_expenses_table', 1),
(78, '2023_03_02_133811_modify_price_fields_in_invoice_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `note` longtext NOT NULL,
  `status_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `noteable_type` varchar(191) NOT NULL,
  `noteable_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(191) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(191) NOT NULL,
  `notifiable_type` varchar(160) NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notification_audiences`
--

CREATE TABLE `notification_audiences` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `notification_setting_id` bigint(20) UNSIGNED NOT NULL,
  `audience_type` varchar(191) NOT NULL,
  `audiences` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notification_audiences`
--

INSERT INTO `notification_audiences` (`id`, `notification_setting_id`, `audience_type`, `audiences`, `created_at`, `updated_at`) VALUES
(1, 1, 'roles', '[1]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(2, 2, 'roles', '[1]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(3, 3, 'roles', '[1]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(4, 4, 'roles', '[1]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(5, 5, 'roles', '[1]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(6, 6, 'roles', '[1,2]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(7, 7, 'roles', '[1,2]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(8, 8, 'roles', '[1,2]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(9, 9, 'roles', '[1,2]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(10, 10, 'roles', '[1,2]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(11, 11, 'roles', '[1,2]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(12, 12, 'roles', '[1]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(13, 13, 'roles', '[1]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(14, 14, 'roles', '[1]', '2023-05-23 18:08:00', '2023-05-23 18:08:00');

-- --------------------------------------------------------

--
-- Table structure for table `notification_channels`
--

CREATE TABLE `notification_channels` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notification_channels`
--

INSERT INTO `notification_channels` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'database', NULL, NULL),
(2, 'mail', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `notification_events`
--

CREATE TABLE `notification_events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `type_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notification_events`
--

INSERT INTO `notification_events` (`id`, `name`, `type_id`, `created_at`, `updated_at`) VALUES
(1, 'user_invitation', 1, NULL, NULL),
(2, 'user_create', 1, NULL, NULL),
(3, 'invoice_sending_attachment', 1, NULL, NULL),
(4, 'password_reset', 1, NULL, NULL),
(5, 'user_joined', 1, NULL, NULL),
(6, 'pipeline_created', 1, NULL, NULL),
(7, 'pipeline_updated', 1, NULL, NULL),
(8, 'pipeline_deleted', 1, NULL, NULL),
(9, 'deal_created', 1, NULL, NULL),
(10, 'deal_updated', 1, NULL, NULL),
(11, 'deal_deleted', 1, NULL, NULL),
(12, 'deal_assigned', 1, NULL, NULL),
(13, 'activity_created', 1, NULL, NULL),
(14, 'activity_reminder', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `notification_event_template`
--

CREATE TABLE `notification_event_template` (
  `notification_event_id` bigint(20) UNSIGNED NOT NULL,
  `notification_template_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notification_event_template`
--

INSERT INTO `notification_event_template` (`notification_event_id`, `notification_template_id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 6),
(5, 5),
(6, 8),
(6, 7),
(7, 10),
(7, 9),
(8, 12),
(8, 11),
(9, 14),
(9, 13),
(10, 16),
(10, 15),
(11, 18),
(11, 17),
(12, 19),
(13, 21),
(13, 20),
(14, 23),
(14, 22);

-- --------------------------------------------------------

--
-- Table structure for table `notification_settings`
--

CREATE TABLE `notification_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `notification_event_id` bigint(20) UNSIGNED NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `notify_by` varchar(191) NOT NULL COMMENT 'List of notification channels.',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notification_settings`
--

INSERT INTO `notification_settings` (`id`, `notification_event_id`, `updated_by`, `notify_by`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, '[\"database\",\"mail\"]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(2, 2, NULL, '[\"database\",\"mail\"]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(3, 3, NULL, '[\"database\",\"mail\"]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(4, 4, NULL, '[\"database\",\"mail\"]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(5, 5, NULL, '[\"database\",\"mail\"]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(6, 6, NULL, '[\"database\",\"mail\"]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(7, 7, NULL, '[\"database\",\"mail\"]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(8, 8, NULL, '[\"database\",\"mail\"]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(9, 9, NULL, '[\"database\",\"mail\"]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(10, 10, NULL, '[\"database\",\"mail\"]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(11, 11, NULL, '[\"database\",\"mail\"]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(12, 12, NULL, '[\"database\",\"mail\"]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(13, 13, NULL, '[\"database\",\"mail\"]', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(14, 14, NULL, '[\"database\",\"mail\"]', '2023-05-23 18:08:00', '2023-05-23 18:08:00');

-- --------------------------------------------------------

--
-- Table structure for table `notification_templates`
--

CREATE TABLE `notification_templates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `subject` text DEFAULT NULL,
  `default_content` longtext DEFAULT NULL,
  `custom_content` longtext DEFAULT NULL,
  `type` enum('sms','mail','database') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notification_templates`
--

INSERT INTO `notification_templates` (`id`, `subject`, `default_content`, `custom_content`, `type`, `created_at`, `updated_at`) VALUES
(1, 'User invitation form {app_name}', '<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name}, </span><br></p><p>Hope this mail finds you well and healthy. We are informing you that you\'ve been invited to our application by {action_by}. It\'ll be a great opportunity to work with you.</p><br>\n<p><a href=\"{invitation_url}\" target=\"_blank\" style=\"background: #4466F2;color: white;padding: 9px;border-radius: 4px;cursor: pointer; text-decoration: none; text-underline: none\">Accept Invitation</a></p><br>\n\n<p></p><p>Thanks &amp; Regards,\n</p><p>{app_name}</p>', NULL, 'mail', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(2, 'Account has been created from {app_name}', '<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n                    <p>\n                    </p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name}</span><br></p><p>Hope this mail finds you well and healthy. You have been added to our company as an employee.\n                    <p>Your Login credentials are below, </p>\n                    <p>Email : {email} </p>\n                    <p>Password : {password}</p>\n                    <br>\n                    <p>Please use these credentials to login into your account.</p><br>\n                    <p><a href=\"{resource_url}\" style=\"background: #4466F2;color: white;padding: 9px;border-radius: 4px;cursor: pointer; text-decoration: none; text-underline: none\" target=\"_blank\">Go to your account</a></p><br>\n                    <p>You can change your password from your account password settings.</p>\n                    Hope you will find useful!\n                    <p></p><p>Thanks &amp; Regards,\n                    </p><p>{app_name}</p>', NULL, 'mail', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(3, 'Invoice {invoice_number} for due {date}', '<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n        <p>\n        </p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hello,</span><br></p><p>Hope you’re doing well.\n        <br>\n        Please see attached deal invoice {invoice_number}.<br>\n         Don’t hesitate to contact us if you have any questions.\n        </p>\n        <p></p><p>Thanks for being with us.\n        </p><p>Regards,</p><p>{app_name}</p><p></p><p></p>', NULL, 'mail', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(4, 'Password reset link provided by {app_name}', '<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name}, </span><br></p><p>Your request for reset password has been approved from {app_name}. Press the button below to reset the password.</p><br>\n<p><a href=\"{reset_password_url}\" style=\"background: #4466F2;color: white;padding: 9px;border-radius: 4px;cursor: pointer; text-decoration: none; text-underline: none\" target=\"_blank\">Reset password</a></p><br>\n\nWe are highly expecting you as soon as possible. Hope you\'ll join us.\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>', NULL, 'mail', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(5, 'A new user has been joined in {app_name}', '<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name},</span><br></p><p>It\'s a piece of good news that a new user {name} has been joined in our application. Hope you will enjoy his work and collaborations.</p><br>\n\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>', NULL, 'mail', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(6, NULL, 'A new user has been joined in {app_name}', NULL, 'database', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(7, ' A new pipeline named {pipeline_name} has been created in {app_name}', '<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name},</span><br></p><p>We are going to inform you that a pipeline named {pipeline_name} has been created in our application by {action_by}. Please have a look at that.</p><br>\n<p><a href=\"{resource_url}\" style=\"background: #4466F2;color: white;padding: 9px;border-radius: 4px;cursor: pointer; ; text-decoration: none; text-underline: none\" target=\"_blank\">View pipeline</a></p><br>\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>', NULL, 'mail', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(8, NULL, 'A new pipeline named {pipeline_name} has been created by {action_by}.', NULL, 'database', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(9, 'A pipeline named {pipeline_name} has been updated in {app_name}', '<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name},</span><br></p><p> We are going to inform you that a pipeline named {pipeline_name} has been updated by {action_by}. </p><br>\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>', NULL, 'mail', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(10, NULL, 'A pipeline named {pipeline_name} has been updated by {action_by}.', NULL, 'database', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(11, 'A pipeline named {pipeline_name} has been deleted in {app_name}', '<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name},</span><br></p><p>We are going to inform you that a pipeline named {pipeline_name} has been deleted by {action_by}.</p>\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>', NULL, 'mail', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(12, NULL, 'A pipeline named {pipeline_name} has been deleted by {action_by}.', NULL, 'database', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(13, 'A new deal named {deal_name} has been created in {app_name}', '<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name},</span><br></p><p>We are going to inform you that a deal named {deal_name} has been created in {pipeline_name} pipeline by {action_by}. Please have a look at that</p>\n<br>\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>', NULL, 'mail', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(14, NULL, 'A new deal named {deal_name} has been created by {action_by}.', NULL, 'database', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(15, 'A deal named {deal_name} has been updated in {app_name}', '<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name},</span> <br></p><p>We are going to inform you that a deal named {deal_name} has been updated by {action_by}. </p><br>\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>', NULL, 'mail', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(16, NULL, 'A deal named {deal_name} has been updated by {action_by}.', NULL, 'database', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(17, 'A deal named {deal_name} has been deleted by {action_by}', '<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name},</span><br></p><p>We are going to inform you that a deal named {deal_name} has been deleted by {action_by}.</p>\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>', NULL, 'mail', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(18, NULL, 'A deal named {deal_name} has been deleted by {action_by}.', NULL, 'database', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(19, 'A deal named {deal_name} has been assigned by {action_by}', '<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<p>\n</p><p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name}, </span><br></p><p>\nWe are going to inform you that a deal named  {deal_name} has been assigned by {action_by}.</p><br>\n<p></p><p>Thanks for being with us.\n</p><p>Regards,</p><p>{app_name}</p><p></p><p></p>', NULL, 'mail', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(20, 'A new activity titled {activity_title} has been created in {app_name}', '<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<br>\n<p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name},</span><br></p><p>We are going to inform you that an activity titled {activity_title} has been created by {action_by}. Please have a look at that.</p>\n<br>\n<p>Activity type: {activity_type}</p>\n<p><b>{contextable_title}</b></p>\n<p>{activity_description}</p>\n<p>Schedule: <a href=\"https://www.timeanddate.com/worldclock/fixedtime.html?{start_timeanddate_query}\">{schedule_start} (UTC)</a> to <a href=\"https://www.timeanddate.com/worldclock/fixedtime.html?{end_timeanddate_query}\">{schedule_end} (UTC)</a></p>\n<p>Related to: {contextable_type} </p>\n<br>\n<br>\n<p>Thanks for being with us.</p>\n<p>Regards,</p><p>{app_name}</p><p></p><p></p>', NULL, 'mail', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(21, NULL, 'A new activity titled {activity_title} has been created by {action_by}.', NULL, 'database', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(22, 'Reminder for activity titled {activity_title} in {app_name}', '<p><img src=\"{app_logo}\" style=\"height: 75px\"></p>\n<br>\n<p><span style=\"background-color: var(--form-control-bg) ; color: var(--default-font-color) ;\">Hi {receiver_name},</span><br></p><p>We reminds you that an activity titled {activity_title}, created by {action_by} will held soon. Please have a look at that.</p>\n<br>\n<p>Activity type: {activity_type}</p>\n<p><b>{contextable_title}</b></p>\n<p>{activity_description}</p>\n<p>Schedule: <a href=\"https://www.timeanddate.com/worldclock/fixedtime.html?{start_timeanddate_query}\">{schedule_start} (UTC)</a> to <a href=\"https://www.timeanddate.com/worldclock/fixedtime.html?{end_timeanddate_query}\">{schedule_end} (UTC)</a></p>\n<p>Related to: {contextable_type} </p>\n<br>\n<br>\n<br>\n<p>Thanks for being with us.</p>\n<p>Regards,</p><p>{app_name}</p><p></p><p></p>', NULL, 'mail', '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(23, NULL, 'Reminder for activity titled {activity_title}.', NULL, 'database', '2023-05-23 18:08:00', '2023-05-23 18:08:00');

-- --------------------------------------------------------

--
-- Table structure for table `organizations`
--

CREATE TABLE `organizations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `address` text DEFAULT NULL,
  `contact_type_id` bigint(20) UNSIGNED NOT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `owner_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `country_id` bigint(20) UNSIGNED DEFAULT NULL,
  `area` text DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `zip_code` varchar(191) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `participants`
--

CREATE TABLE `participants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `deal_id` bigint(20) UNSIGNED NOT NULL,
  `person_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_histories`
--

CREATE TABLE `password_histories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `password` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(160) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `people`
--

CREATE TABLE `people` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `address` text DEFAULT NULL,
  `contact_type_id` bigint(20) UNSIGNED NOT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `owner_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `country_id` bigint(20) UNSIGNED DEFAULT NULL,
  `area` text DEFAULT NULL,
  `state` varchar(191) DEFAULT NULL,
  `city` varchar(191) DEFAULT NULL,
  `zip_code` varchar(191) DEFAULT NULL,
  `attach_login_user_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `group_name` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `type_id`, `name`, `group_name`, `created_at`, `updated_at`) VALUES
(1, 1, 'list_view_settings', 'settings', NULL, NULL),
(2, 1, 'view_settings', 'settings', NULL, NULL),
(3, 1, 'update_settings', 'settings', NULL, NULL),
(4, 1, 'update_delivery_settings', 'settings', NULL, NULL),
(5, 1, 'view_delivery_settings', 'settings', NULL, NULL),
(6, 1, 'list_notifications', 'notifications', NULL, NULL),
(7, 1, 'view_notification_event', 'notifications', NULL, NULL),
(8, 1, 'update_notification_templates', 'notifications', NULL, NULL),
(9, 1, 'view_notification_channels', 'notifications', NULL, NULL),
(10, 1, 'manage_notification_audience', 'notifications', NULL, NULL),
(11, 1, 'view_custom_fields', 'custom_fields', NULL, NULL),
(12, 1, 'create_custom_fields', 'custom_fields', NULL, NULL),
(13, 1, 'update_custom_fields', 'custom_fields', NULL, NULL),
(14, 1, 'delete_custom_fields', 'custom_fields', NULL, NULL),
(15, 1, 'view_activity_logs', 'log', NULL, NULL),
(16, 1, 'invite_user', 'users', NULL, NULL),
(17, 1, 'view_users', 'users', NULL, NULL),
(18, 1, 'update_users', 'users', NULL, NULL),
(19, 1, 'delete_users', 'users', NULL, NULL),
(20, 1, 'attach_roles_users', 'users', NULL, NULL),
(21, 1, 'detach_roles_users', 'users', NULL, NULL),
(22, 1, 'user_active', 'users', NULL, NULL),
(23, 1, 'user_deactive', 'users', NULL, NULL),
(24, 1, 'view_roles', 'roles', NULL, NULL),
(25, 1, 'create_roles', 'roles', NULL, NULL),
(26, 1, 'update_roles', 'roles', NULL, NULL),
(27, 1, 'delete_roles', 'roles', NULL, NULL),
(28, 1, 'attach_users_to_roles', 'roles', NULL, NULL),
(29, 1, 'attach_permissions_roles', 'permissions', NULL, NULL),
(30, 1, 'detach_permissions_roles', 'permissions', NULL, NULL),
(31, 1, 'manage_dashboard', 'dashboard', NULL, NULL),
(32, 1, 'manage_public_access', 'public_access_behavior', NULL, NULL),
(33, 1, 'client_access', 'clients', NULL, NULL),
(34, 1, 'user_info_lead', 'clients', NULL, NULL),
(35, 2, 'view_persons', 'persons', NULL, NULL),
(36, 2, 'create_persons', 'persons', NULL, NULL),
(37, 2, 'update_persons', 'persons', NULL, NULL),
(38, 2, 'delete_persons', 'persons', NULL, NULL),
(39, 2, 'invite_lead_person', 'persons', NULL, NULL),
(40, 2, 'import_persons', 'persons', NULL, NULL),
(41, 2, 'export_person', 'persons', NULL, NULL),
(42, 2, 'upload_profile_picture_of_persons', 'persons', NULL, NULL),
(43, 2, 'sync_tags_persons', 'persons', NULL, NULL),
(44, 2, 'sync_followers_persons', 'persons', NULL, NULL),
(45, 2, 'sync_contact_persons', 'persons', NULL, NULL),
(46, 2, 'sync_organizations_persons', 'persons', NULL, NULL),
(47, 2, 'view_activities_persons', 'persons', NULL, NULL),
(48, 2, 'sync_activities_person', 'persons', NULL, NULL),
(49, 2, 'sync_file_person', 'persons', NULL, NULL),
(50, 2, 'sync_note_person', 'persons', NULL, NULL),
(51, 2, 'view_organizations', 'organizations', NULL, NULL),
(52, 2, 'create_organizations', 'organizations', NULL, NULL),
(53, 2, 'update_organizations', 'organizations', NULL, NULL),
(54, 2, 'delete_organizations', 'organizations', NULL, NULL),
(55, 2, 'import_organization', 'organizations', NULL, NULL),
(56, 2, 'export_organization', 'organizations', NULL, NULL),
(57, 2, 'upload_profile_picture_of_organizations', 'organizations', NULL, NULL),
(58, 2, 'sync_tags_organizations', 'organizations', NULL, NULL),
(59, 2, 'sync_followers_organizations', 'organizations', NULL, NULL),
(60, 2, 'sync_contact_organizations', 'organizations', NULL, NULL),
(61, 2, 'sync_person_organizations', 'organizations', NULL, NULL),
(62, 2, 'person_org_deal', 'organizations', NULL, NULL),
(63, 2, 'sync_follower_organizations', 'organizations', NULL, NULL),
(64, 2, 'view_activities_organizations', 'organizations', NULL, NULL),
(65, 2, 'sync_activities_organization', 'organizations', NULL, NULL),
(66, 2, 'sync_file_organization', 'organizations', NULL, NULL),
(67, 2, 'sync_note_organization', 'organizations', NULL, NULL),
(68, 2, 'view_types', 'lead_groups', NULL, NULL),
(69, 2, 'create_types', 'lead_groups', NULL, NULL),
(70, 2, 'update_types', 'lead_groups', NULL, NULL),
(71, 2, 'delete_types', 'lead_groups', NULL, NULL),
(72, 2, 'view_deals', 'deals', NULL, NULL),
(73, 2, 'page_deals_pipeline', 'deals', NULL, NULL),
(74, 2, 'create_deals', 'deals', NULL, NULL),
(75, 2, 'update_deals', 'deals', NULL, NULL),
(76, 2, 'delete_deals', 'deals', NULL, NULL),
(77, 2, 'owner_deals', 'deals', NULL, NULL),
(78, 2, 'details_deal', 'deals', NULL, NULL),
(79, 2, 'import_deal', 'deals', NULL, NULL),
(80, 2, 'export_deal', 'deals', NULL, NULL),
(81, 2, 'move_multiple_deals', 'deals', NULL, NULL),
(82, 2, 'proposal_send_deal_person', 'deals', NULL, NULL),
(83, 2, 'sync_activities_deal', 'deals', NULL, NULL),
(84, 2, 'sync_followers_deal', 'deals', NULL, NULL),
(85, 2, 'sync_tags_deal', 'deals', NULL, NULL),
(86, 2, 'sync_note_deal', 'deals', NULL, NULL),
(87, 2, 'sync_file_deal', 'deals', NULL, NULL),
(88, 2, 'view_activities_deal', 'deals', NULL, NULL),
(89, 2, 'delete_person_deal', 'deals', NULL, NULL),
(90, 2, 'delete_organization_deal', 'deals', NULL, NULL),
(91, 2, 'sync_participants_deal', 'deals', NULL, NULL),
(92, 2, 'revision_history_deal', 'deals', NULL, NULL),
(93, 2, 'deal_reports', 'deals', NULL, NULL),
(94, 2, 'view_discussions', 'discussions', NULL, NULL),
(95, 2, 'create_discussions', 'discussions', NULL, NULL),
(96, 2, 'update_discussions', 'discussions', NULL, NULL),
(97, 2, 'delete_discussions', 'discussions', NULL, NULL),
(98, 2, 'view_pipelines', 'pipelines', NULL, NULL),
(99, 2, 'create_pipelines', 'pipelines', NULL, NULL),
(100, 2, 'update_pipelines', 'pipelines', NULL, NULL),
(101, 2, 'delete_pipelines', 'pipelines', NULL, NULL),
(102, 2, 'pipeline_reports', 'pipelines', NULL, NULL),
(103, 2, 'view_stages', 'stages', NULL, NULL),
(104, 2, 'create_stages', 'stages', NULL, NULL),
(105, 2, 'update_stages', 'stages', NULL, NULL),
(106, 2, 'delete_stages', 'stages', NULL, NULL),
(107, 2, 'view_lost_reasons', 'lost_reasons', NULL, NULL),
(108, 2, 'create_lost_reasons', 'lost_reasons', NULL, NULL),
(109, 2, 'update_lost_reasons', 'lost_reasons', NULL, NULL),
(110, 2, 'delete_lost_reasons', 'lost_reasons', NULL, NULL),
(111, 2, 'view_proposals', 'proposals', NULL, NULL),
(112, 2, 'create_proposals', 'proposals', NULL, NULL),
(113, 2, 'update_proposals', 'proposals', NULL, NULL),
(114, 2, 'delete_proposals', 'proposals', NULL, NULL),
(115, 2, 'copy_proposals', 'proposals', NULL, NULL),
(116, 2, 'send_proposals', 'proposals', NULL, NULL),
(117, 2, 'add_proposals', 'proposals', NULL, NULL),
(118, 2, 'proposal_reports', 'proposals', NULL, NULL),
(119, 2, 'view_activities', 'activities', NULL, NULL),
(120, 2, 'create_activities', 'activities', NULL, NULL),
(121, 2, 'update_activities', 'activities', NULL, NULL),
(122, 2, 'delete_activities', 'activities', NULL, NULL),
(123, 2, 'done_activities', 'activities', NULL, NULL),
(124, 2, 'view_templates', 'templates', NULL, NULL),
(125, 2, 'create_templates', 'templates', NULL, NULL),
(126, 2, 'update_templates', 'templates', NULL, NULL),
(127, 2, 'delete_templates', 'templates', NULL, NULL),
(128, 2, 'copy_templates', 'templates', NULL, NULL),
(129, 2, 'view_invoice', 'invoices', NULL, NULL),
(130, 2, 'create_invoice', 'invoices', NULL, NULL),
(131, 2, 'update_invoice', 'invoices', NULL, NULL),
(132, 2, 'delete_invoice', 'invoices', NULL, NULL),
(133, 2, 'download_invoice', 'invoices', NULL, NULL),
(134, 2, 'invoice_get_deal_contact_person', 'invoices', NULL, NULL),
(135, 2, 'invoice_sending_attachment_mail', 'invoices', NULL, NULL),
(136, 2, 'bulk_attach_organizations_person', 'bulk_actions', NULL, NULL),
(137, 2, 'bulk_update_lead_group_person', 'bulk_actions', NULL, NULL),
(138, 2, 'bulk_update_owner_person', 'bulk_actions', NULL, NULL),
(139, 2, 'bulk_attach_tags_person', 'bulk_actions', NULL, NULL),
(140, 2, 'bulk_delete_person', 'bulk_actions', NULL, NULL),
(141, 2, 'bulk_attach_persons_organization', 'bulk_actions', NULL, NULL),
(142, 2, 'bulk_update_lead_group_organization', 'bulk_actions', NULL, NULL),
(143, 2, 'bulk_update_owner_organization', 'bulk_actions', NULL, NULL),
(144, 2, 'bulk_attach_tags_organization', 'bulk_actions', NULL, NULL),
(145, 2, 'bulk_delete_organization', 'bulk_actions', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `person_organization`
--

CREATE TABLE `person_organization` (
  `person_id` bigint(20) UNSIGNED NOT NULL,
  `organization_id` bigint(20) UNSIGNED NOT NULL,
  `job_title` varchar(191) DEFAULT 'No Title'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `phones`
--

CREATE TABLE `phones` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `value` varchar(191) NOT NULL,
  `type_id` bigint(20) UNSIGNED DEFAULT NULL,
  `contextable_type` varchar(191) DEFAULT NULL,
  `contextable_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `phone_email_types`
--

CREATE TABLE `phone_email_types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `class` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `phone_email_types`
--

INSERT INTO `phone_email_types` (`id`, `name`, `class`, `created_at`, `updated_at`) VALUES
(1, 'work', 'success', NULL, NULL),
(2, 'home', 'info', NULL, NULL),
(3, 'office', 'warning', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pipelines`
--

CREATE TABLE `pipelines` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `gender` enum('male','female','other') NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `contact` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `proposals`
--

CREATE TABLE `proposals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `subject` varchar(191) NOT NULL,
  `content` longtext NOT NULL,
  `status_id` bigint(20) UNSIGNED DEFAULT NULL,
  `deal_id` bigint(20) UNSIGNED DEFAULT NULL,
  `owner_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expired_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `revisions`
--

CREATE TABLE `revisions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `revisionable_type` varchar(191) NOT NULL,
  `revisionable_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `key` varchar(191) NOT NULL,
  `old_value` text DEFAULT NULL,
  `new_value` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(160) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `type_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `is_admin`, `is_default`, `type_id`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'App Admin', 1, 1, 1, 1, NULL, NULL),
(2, 'Manager', 0, 1, 1, 1, NULL, NULL),
(3, 'Agent', 0, 1, 1, 1, NULL, NULL),
(4, 'Client', 0, 1, 1, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `role_permission`
--

CREATE TABLE `role_permission` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `meta` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_permission`
--

INSERT INTO `role_permission` (`role_id`, `permission_id`, `meta`) VALUES
(2, 6, NULL),
(3, 6, NULL),
(4, 6, NULL),
(2, 7, NULL),
(3, 7, NULL),
(2, 8, NULL),
(3, 8, NULL),
(2, 9, NULL),
(3, 9, NULL),
(2, 10, NULL),
(3, 10, NULL),
(2, 11, NULL),
(3, 11, NULL),
(2, 12, NULL),
(3, 12, NULL),
(2, 13, NULL),
(3, 13, NULL),
(2, 14, NULL),
(3, 14, NULL),
(2, 15, NULL),
(3, 15, NULL),
(2, 31, NULL),
(3, 31, NULL),
(4, 31, NULL),
(2, 32, NULL),
(4, 33, NULL),
(4, 34, NULL),
(2, 35, NULL),
(3, 35, NULL),
(2, 36, NULL),
(3, 36, NULL),
(2, 37, NULL),
(3, 37, NULL),
(2, 38, NULL),
(3, 38, NULL),
(2, 39, NULL),
(3, 39, NULL),
(2, 40, NULL),
(3, 40, NULL),
(2, 41, NULL),
(2, 42, NULL),
(3, 42, NULL),
(2, 43, NULL),
(3, 43, NULL),
(2, 44, NULL),
(3, 44, NULL),
(2, 45, NULL),
(3, 45, NULL),
(2, 46, NULL),
(3, 46, NULL),
(2, 47, NULL),
(3, 47, NULL),
(2, 48, NULL),
(3, 48, NULL),
(2, 49, NULL),
(3, 49, NULL),
(2, 50, NULL),
(3, 50, NULL),
(2, 51, NULL),
(3, 51, NULL),
(4, 51, NULL),
(2, 52, NULL),
(3, 52, NULL),
(2, 53, NULL),
(3, 53, NULL),
(2, 54, NULL),
(3, 54, NULL),
(2, 55, NULL),
(3, 55, NULL),
(2, 56, NULL),
(2, 57, NULL),
(3, 57, NULL),
(2, 58, NULL),
(3, 58, NULL),
(2, 59, NULL),
(3, 59, NULL),
(2, 60, NULL),
(3, 60, NULL),
(2, 61, NULL),
(3, 61, NULL),
(2, 62, NULL),
(3, 62, NULL),
(2, 63, NULL),
(3, 63, NULL),
(2, 64, NULL),
(3, 64, NULL),
(2, 65, NULL),
(3, 65, NULL),
(2, 66, NULL),
(3, 66, NULL),
(2, 67, NULL),
(3, 67, NULL),
(2, 68, NULL),
(3, 68, NULL),
(2, 69, NULL),
(2, 70, NULL),
(2, 71, NULL),
(2, 72, NULL),
(3, 72, NULL),
(4, 72, NULL),
(2, 73, NULL),
(3, 73, NULL),
(2, 74, NULL),
(3, 74, NULL),
(2, 75, NULL),
(3, 75, NULL),
(2, 76, NULL),
(3, 76, NULL),
(2, 77, NULL),
(3, 77, NULL),
(2, 78, NULL),
(3, 78, NULL),
(2, 79, NULL),
(3, 79, NULL),
(2, 80, NULL),
(2, 81, NULL),
(3, 81, NULL),
(2, 82, NULL),
(3, 82, NULL),
(2, 83, NULL),
(3, 83, NULL),
(2, 84, NULL),
(3, 84, NULL),
(2, 85, NULL),
(3, 85, NULL),
(2, 86, NULL),
(3, 86, NULL),
(2, 87, NULL),
(3, 87, NULL),
(2, 88, NULL),
(3, 88, NULL),
(2, 89, NULL),
(3, 89, NULL),
(2, 90, NULL),
(3, 90, NULL),
(2, 91, NULL),
(3, 91, NULL),
(2, 92, NULL),
(3, 92, NULL),
(2, 93, NULL),
(2, 94, NULL),
(3, 94, NULL),
(4, 94, NULL),
(2, 95, NULL),
(3, 95, NULL),
(4, 95, NULL),
(2, 96, NULL),
(3, 96, NULL),
(4, 96, NULL),
(2, 97, NULL),
(3, 97, NULL),
(4, 97, NULL),
(2, 98, NULL),
(3, 98, NULL),
(4, 98, NULL),
(2, 99, NULL),
(2, 100, NULL),
(2, 101, NULL),
(2, 102, NULL),
(2, 103, NULL),
(2, 104, NULL),
(2, 105, NULL),
(2, 106, NULL),
(2, 107, NULL),
(3, 107, NULL),
(2, 108, NULL),
(2, 109, NULL),
(2, 110, NULL),
(2, 111, NULL),
(3, 111, NULL),
(4, 111, NULL),
(2, 112, NULL),
(3, 112, NULL),
(2, 113, NULL),
(3, 113, NULL),
(2, 114, NULL),
(3, 114, NULL),
(2, 115, NULL),
(3, 115, NULL),
(2, 116, NULL),
(3, 116, NULL),
(2, 117, NULL),
(2, 118, NULL),
(2, 119, NULL),
(3, 119, NULL),
(2, 120, NULL),
(3, 120, NULL),
(2, 121, NULL),
(3, 121, NULL),
(2, 122, NULL),
(3, 122, NULL),
(2, 123, NULL),
(3, 123, NULL),
(2, 124, NULL),
(3, 124, NULL),
(2, 125, NULL),
(2, 126, NULL),
(2, 127, NULL),
(2, 128, NULL),
(2, 129, NULL),
(3, 129, NULL),
(4, 129, NULL),
(2, 130, NULL),
(3, 130, NULL),
(2, 131, NULL),
(3, 131, NULL),
(2, 132, NULL),
(3, 132, NULL),
(2, 133, NULL),
(3, 133, NULL),
(4, 133, NULL),
(2, 134, NULL),
(3, 134, NULL),
(2, 135, NULL),
(3, 135, NULL),
(3, 136, NULL),
(3, 137, NULL),
(3, 138, NULL),
(3, 139, NULL),
(3, 140, NULL),
(3, 141, NULL),
(3, 142, NULL),
(3, 143, NULL),
(3, 144, NULL),
(3, 145, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`user_id`, `role_id`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(120) NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` text NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `value` longtext DEFAULT NULL,
  `settingable_type` varchar(160) DEFAULT NULL,
  `settingable_id` bigint(20) UNSIGNED DEFAULT NULL,
  `context` varchar(191) DEFAULT NULL,
  `autoload` tinyint(1) NOT NULL DEFAULT 0,
  `public` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `settingable_type`, `settingable_id`, `context`, `autoload`, `public`, `created_at`, `updated_at`) VALUES
(1, 'purchase_code', '5555-9456-999-4560', NULL, NULL, 'purchase_code', 0, 1, '2023-05-23 18:08:00', '2023-05-23 18:08:00'),
(2, 'company_name', 'Ingenious CRM', NULL, NULL, 'app', 0, 1, NULL, '2023-05-23 21:25:48'),
(3, 'company_logo', '/storage/logo/646d2f5d057cb.png', NULL, NULL, 'app', 0, 1, NULL, '2023-05-23 21:25:49'),
(4, 'company_icon', '/storage/icon/646d2f5d6a9f2.ico', NULL, NULL, 'app', 0, 1, NULL, '2023-05-23 21:25:49'),
(5, 'company_banner', '/images/banner.jpg', NULL, NULL, 'app', 0, 1, NULL, NULL),
(6, 'language', 'en', NULL, NULL, 'app', 0, 1, NULL, NULL),
(7, 'date_format', 'd-m-Y', NULL, NULL, 'app', 0, 1, NULL, NULL),
(8, 'time_format', 'h', NULL, NULL, 'app', 0, 1, NULL, NULL),
(9, 'time_zone', 'Asia/Kuala_Lumpur', NULL, NULL, 'app', 0, 1, NULL, '2023-05-23 21:25:49'),
(10, 'currency_symbol', '$', NULL, NULL, 'app', 0, 1, NULL, NULL),
(11, 'decimal_separator', '.', NULL, NULL, 'app', 0, 1, NULL, NULL),
(12, 'thousand_separator', ',', NULL, NULL, 'app', 0, 1, NULL, NULL),
(13, 'number_of_decimal', '2', NULL, NULL, 'app', 0, 1, NULL, NULL),
(14, 'currency_position', 'prefix_with_space', NULL, NULL, 'app', 0, 1, NULL, NULL),
(15, 'invoice_logo', '/images/invoice-logo.png', NULL, NULL, 'app', 0, 1, NULL, NULL),
(16, 'invoice_starting_number', '1', NULL, NULL, 'app', 0, 1, NULL, NULL),
(17, 'invoice_prefix', 'INV', NULL, NULL, 'app', 0, 1, NULL, NULL),
(18, 'from_name', 'eyJpdiI6IjBDamQxZC94VlhsOUMzWnYyditLSGc9PSIsInZhbHVlIjoiZE1QK0tzSU82NklLZHhRNHFrWlJmUmZwdmpnWjR0Vmo1d2NhMUxwUTN6ST0iLCJtYWMiOiJiNmMyMmFmMTI5MDFjMWRjMGQ1N2U0NzlkMzU3MDc1Njg2OTFlNWI1NzcyMjYwM2YzNTVkOTU4NDY0ZjEzZTY4IiwidGFnIjoiIn0=', NULL, NULL, 'default_mail_email_name', 0, 1, '2023-05-23 18:09:26', '2023-05-23 18:09:26'),
(19, 'from_email', 'eyJpdiI6IjdPQzBoVi94cnpsaFRtZ1FyR0dzOHc9PSIsInZhbHVlIjoiQjZmZjJIWXk3aHpNVTkxZnJSdHRhSjlIWUI4MmF5b011V2s3Mi9iaTZxUT0iLCJtYWMiOiJkZGRjMDdjOWNhN2Q3M2YxZjA0YTc3NGFiMWI1OWY5ODZlYjBlYjU1NmE0NTQ4OTEzMzNjNTdhZGM5M2E5NjgxIiwidGFnIjoiIn0=', NULL, NULL, 'default_mail_email_name', 0, 1, '2023-05-23 18:09:26', '2023-05-23 18:09:26'),
(20, 'region', 'eyJpdiI6Iit6NWxqWGRaSDVOQ0VLNGFaenVzNVE9PSIsInZhbHVlIjoic2ZocDBXYWVNQ3R2UGtuYjdIQU45Uitnc2xXdEVVYUh2OWJMZjVBOWhLdz0iLCJtYWMiOiI5YjUzNDIzODFkNDc5ZGJjY2ZhNDEzYzhjYmVmZjdiOTA4YTFlMTdiMWRiYWNiYTVmMmE4ZmVkYWJjZjgxNGEyIiwidGFnIjoiIn0=', NULL, NULL, 'smtp', 0, 1, '2023-05-23 18:09:26', '2023-05-23 18:09:26'),
(21, 'provider', 'eyJpdiI6IjdyQWtzeHhJeDdBS25zN2Qzb0hYVEE9PSIsInZhbHVlIjoiTitmT240N0VySGlPakxwVVN2bmw2UT09IiwibWFjIjoiNjcxMTc5ZDQyZDFiNWZmYWYxNTdjYTU3YmQ3NzQ5NTA0OTYzNDFlZjVhZWI3MjI5YmYzMTViOWM0MjZjM2E3YyIsInRhZyI6IiJ9', NULL, NULL, 'smtp', 0, 1, '2023-05-23 18:09:26', '2023-05-23 18:09:26'),
(22, 'encryption_type', 'eyJpdiI6IlBvaVZKQ01TY2I2Yk5iOVBaUUwzdXc9PSIsInZhbHVlIjoibU4wV2I5c1g0cGdXRUFtUW5Cbi9zQT09IiwibWFjIjoiZWFkM2NkMjgyZjg2OTA1ODI4YTAzOTk4ODQ0MDMwZWQ2MzZiOTY3N2Y4ZmJhYzA1ODg0ZmMzYzE4OTgwNjEzMiIsInRhZyI6IiJ9', NULL, NULL, 'smtp', 0, 1, '2023-05-23 18:09:26', '2023-05-23 18:09:26'),
(23, 'email_password', 'eyJpdiI6IlBob2VNTjFsdTBTelQzZ3lJdE12ckE9PSIsInZhbHVlIjoic1RXZ0plbmpUTkZCKzU0bnhWQlQyTW43T3BQTEVVYTlCdGlwUVU2QmttND0iLCJtYWMiOiJjNDFhZGNmN2U4NWExNGNmZWM4MmI3ZjgzNTVkYzM3YmRhNDQ3Njk4NzZjN2YwOTIyYmJiMGFkMTc1ZGJhNDA3IiwidGFnIjoiIn0=', NULL, NULL, 'smtp', 0, 1, '2023-05-23 18:09:26', '2023-05-23 18:09:26'),
(24, 'smtp_port', 'eyJpdiI6IndpT0tuQzJ3YmJqUFpyRm1CT0V3S0E9PSIsInZhbHVlIjoiSTA3YkpZQkVFVVNES2ovYUM4ZDhadz09IiwibWFjIjoiMTg1MTc4ZTliNjFmMjk3YjE3NjcwYzY3MTUzY2MwMmQ2ZGM3MDY5YzY3ODcyYjJhN2YxOTNiNzRmY2QyZDAwNCIsInRhZyI6IiJ9', NULL, NULL, 'smtp', 0, 1, '2023-05-23 18:09:26', '2023-05-23 18:09:26'),
(25, 'smtp_host', 'eyJpdiI6IllwYWhzMVc5TEJCVzJjMUExUGZEVlE9PSIsInZhbHVlIjoiRVNVVkRuMWROVG9VbTI5Sno1SjJpb3l1ZVNlMm5FN0MyRGQvL01wVGJpQT0iLCJtYWMiOiJlNGI4N2QyYzkxN2JmZDFmYjc3MWY1ZDIwMjNlYzc2MTNhNzQwNjNmODY0ZmRlZjRmYjg0MzkwNWExY2YzYjMyIiwidGFnIjoiIn0=', NULL, NULL, 'smtp', 0, 1, '2023-05-23 18:09:26', '2023-05-23 18:09:26'),
(26, 'smtp_user_name', 'eyJpdiI6IjNiZEtCbmRSQW9xem1hbldpTm9QeUE9PSIsInZhbHVlIjoidTMxdXJxWXpPS2VISWdjRjZwM1IzUT09IiwibWFjIjoiNTViYTc1M2U2OTRkZDQzYWIyYmZhZjA5ZWM2YzE2NzU3ZjQzNDQyNWMwNzVhY2Y3ZTQ4NDQxY2U4NDI2M2RlMCIsInRhZyI6IiJ9', NULL, NULL, 'smtp', 0, 1, '2023-05-23 18:09:26', '2023-05-23 18:09:26'),
(27, 'api_key', 'eyJpdiI6InhvUmhOSjdVcW1QRVZmdDJFSU1XUUE9PSIsInZhbHVlIjoibWVBMkZPYVoyZlpuZmViTkR6VXY0Zz09IiwibWFjIjoiZmM2YmEwMzY3MzgxMmRlMWJiMzZkOTk5ODIyZGU0ODM0MDZhMDdhNWE5MDI4MmU2NjU1Zjc4MjE4ZTU5M2U5OSIsInRhZyI6IiJ9', NULL, NULL, 'smtp', 0, 1, '2023-05-23 18:09:26', '2023-05-23 18:09:26'),
(28, 'secret_access_key', 'eyJpdiI6IkFUWmpJM1hUTldINU4zN2YyUDgyRWc9PSIsInZhbHVlIjoiWGkxTU1MV2FnbHFNUytJYWZOK09rdz09IiwibWFjIjoiNDQxZjVhZGEzMjAxNjc2ODllYzUxZTgzZjEyZTQyZTY1NDVlYzg3MjY3MGQ5YjM5OTQ0NzA1OGVmYjdlZjYxZiIsInRhZyI6IiJ9', NULL, NULL, 'smtp', 0, 1, '2023-05-23 18:09:26', '2023-05-23 18:09:26'),
(29, 'domain_name', 'eyJpdiI6Im5QQnk0TG1pdkpaMVpGOUpBMlAzSWc9PSIsInZhbHVlIjoiWUNndzR0ZURXM0d3aE5OblcwL0piZz09IiwibWFjIjoiZDI2YjZlNDE3MDFhNzc1YzViNmQ3ODc0Y2RiNTAwYzExZmJlZmVhZTg3ZmQ2NWU5MDFiODViOGM4OTRlOGI3MyIsInRhZyI6IiJ9', NULL, NULL, 'smtp', 0, 1, '2023-05-23 18:09:26', '2023-05-23 18:09:26'),
(30, 'access_key_id', 'eyJpdiI6IjdEZ1Mzcmk4SFBzSEFuREMzc2ZHMUE9PSIsInZhbHVlIjoiVy9aQk5iR1ZHRURkN29YWlFpMmlIdz09IiwibWFjIjoiOTVmZDYwYzQxYTQxZDM3MWRhY2FhZTZiMGZhNDQ0ZTA0ZjAyODM2YWE1YTA3MDE0MWM5MzRjNzA1ZjQ4ZmQ0YyIsInRhZyI6IiJ9', NULL, NULL, 'smtp', 0, 1, '2023-05-23 18:09:26', '2023-05-23 18:09:26'),
(31, 'default_mail', 'smtp', NULL, NULL, 'mail', 0, 1, '2023-05-23 18:09:26', '2023-05-23 18:09:26'),
(32, 'pusher_app_id', 'eyJpdiI6IllyODJiWHFWOXc1c1RMcjhhUzRHanc9PSIsInZhbHVlIjoibjVoSlZ0ZldoSlZpQ2ROdUdQYVZkRDd0NkZkT3hraGE4Z3kwVjV2aHZTRT0iLCJtYWMiOiI4ODA0NzU0OGU5NTc4MzIwOWQ0ZGRjZjM5MjczMmI0OGRmM2Y1NDkwYTRlOWE3MDNlYjI3YzY2MmY3MGY2MDkxIiwidGFnIjoiIn0=', NULL, NULL, 'default_broadcast_driver_name', 0, 1, '2023-05-23 18:09:54', '2023-05-23 18:09:54'),
(33, 'pusher_app_key', 'eyJpdiI6IjZhUUdFVHNsdDJMUVFuUnVDYnF2Z2c9PSIsInZhbHVlIjoidE11aXc4aE9wRUFzdWdjNkFsQVFUaUNEbjQrYWE3eWVWWFRmVmxLZXRmbz0iLCJtYWMiOiI4Y2IyNzhkODdiMjFlOWM4ODQ0NTYyZWI0NzMyMGZlOTA0MTU3NDQzOTdhM2YwNGVhNmRmZjNhYTUyNDRjNGU2IiwidGFnIjoiIn0=', NULL, NULL, 'default_broadcast_driver_name', 0, 1, '2023-05-23 18:09:54', '2023-05-23 18:09:54'),
(34, 'pusher_app_secret', 'eyJpdiI6InNzVDl6QU11cEFxcnZjV1hUVlZKTmc9PSIsInZhbHVlIjoiSnpFMlJ5S2RuaDNPaFgwdzlGblNqWUpBdGlZVkYrL01iazUxQ21yZFJ2Yz0iLCJtYWMiOiJjMTcxMzJhMDlkOTc3YjdjMzIwMTVkMmMwYjM2ZmMyNjk1OWM5YzA2YTk0ZGI2YzlmNzQ1NmJlMmQ3NWI1ODg4IiwidGFnIjoiIn0=', NULL, NULL, 'default_broadcast_driver_name', 0, 1, '2023-05-23 18:09:54', '2023-05-23 18:09:54'),
(35, 'pusher_app_cluster', 'eyJpdiI6IkhDNEt6Zm5uNXRLZDJZSXRIY0VTaUE9PSIsInZhbHVlIjoiWUgzaFNobithV0lRT2pwbUZ5MWhBZi8vZ01qdEJKNU1yeDM2dG1oQ3FMTT0iLCJtYWMiOiIzMWIxMGJjNTFhNjNiM2MyMWJhYmNlYWE5OTU2YmNhNDk4MjVmNTUwODkyMThkMzkyYmFkN2JjODlhNGZmZjQ1IiwidGFnIjoiIn0=', NULL, NULL, 'default_broadcast_driver_name', 0, 1, '2023-05-23 18:09:54', '2023-05-23 18:09:54'),
(36, 'broadcast_driver', 'eyJpdiI6IjJwZWxRMGlHSXNFL3JzSkNOWVVzMVE9PSIsInZhbHVlIjoiUHU2UTY1YWZadTFXWjA5SDgxL0JMUT09IiwibWFjIjoiOWYzZDc3ZjBjMTNkM2IxZGY1MzgzNmY4MDNmZDMwNGU2YTFjNjI5MDhkNzRjZjc3OTk3YzA3ZWRjZjFlZmEyNSIsInRhZyI6IiJ9', NULL, NULL, 'pusher', 0, 1, '2023-05-23 18:09:54', '2023-05-23 18:09:54'),
(37, 'default_broadcast', 'pusher', NULL, NULL, 'broadcast', 0, 1, '2023-05-23 18:09:54', '2023-05-23 18:09:54');

-- --------------------------------------------------------

--
-- Table structure for table `stages`
--

CREATE TABLE `stages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `probability` int(11) DEFAULT 100,
  `pipeline_id` bigint(20) UNSIGNED NOT NULL,
  `priority` int(11) NOT NULL DEFAULT 0,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `statuses`
--

CREATE TABLE `statuses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `class` varchar(191) DEFAULT NULL,
  `type` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `statuses`
--

INSERT INTO `statuses` (`id`, `name`, `class`, `type`, `created_at`, `updated_at`) VALUES
(1, 'status_active', 'success', 'user', NULL, NULL),
(2, 'status_inactive', 'danger', 'user', NULL, NULL),
(3, 'status_invited', 'purple', 'user', NULL, NULL),
(4, 'status_open', 'success', 'crm', NULL, NULL),
(5, 'status_closed', 'danger', 'crm', NULL, NULL),
(6, 'status_draft', 'warning', 'proposal', NULL, NULL),
(7, 'status_sent', 'primary', 'proposal', NULL, NULL),
(8, 'status_accepted', 'success', 'proposal', NULL, NULL),
(9, 'status_rejected', 'danger', 'proposal', NULL, NULL),
(10, 'status_no_reply', 'info', 'proposal', NULL, NULL),
(11, 'status_todo', 'primary', 'activity', NULL, NULL),
(12, 'status_done', 'success', 'activity', NULL, NULL),
(13, 'status_open', 'primary', 'deal', NULL, NULL),
(14, 'status_won', 'success', 'deal', NULL, NULL),
(15, 'status_lost', 'danger', 'deal', NULL, NULL),
(16, 'status_unpaid', 'danger', 'invoice', NULL, NULL),
(17, 'status_paid', 'success', 'invoice', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `table_filters`
--

CREATE TABLE `table_filters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `table_id` varchar(191) NOT NULL,
  `filter_name` varchar(191) NOT NULL,
  `filter_value` varchar(191) DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taggables`
--

CREATE TABLE `taggables` (
  `tag_id` bigint(20) UNSIGNED NOT NULL,
  `taggable_type` varchar(191) DEFAULT NULL,
  `taggable_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `color_code` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taxes`
--

CREATE TABLE `taxes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `value` double(8,2) NOT NULL COMMENT 'tax percentage',
  `tenant_id` bigint(20) UNSIGNED NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE `templates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `subject` text DEFAULT NULL,
  `default_content` longtext DEFAULT NULL,
  `custom_content` longtext DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE `types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) NOT NULL,
  `alias` varchar(80) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`id`, `name`, `alias`, `created_at`, `updated_at`) VALUES
(1, 'App', 'app', NULL, NULL),
(2, 'CRM', 'crm', NULL, NULL),
(3, 'Brand', 'brand', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(191) DEFAULT NULL,
  `last_name` varchar(191) DEFAULT NULL,
  `email` varchar(160) NOT NULL,
  `password` varchar(191) DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `status_id` bigint(20) UNSIGNED NOT NULL,
  `invitation_token` varchar(191) DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `last_login_at`, `created_by`, `status_id`, `invitation_token`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Super', 'Admin', 'admin@admin.com', '$2y$10$GXugR5UwIfp37q9Eg94DfuC52D2tB7vV2V33SyJJj8m9readuesdG', NULL, NULL, 1, NULL, NULL, '2023-05-23 18:08:00', '2023-05-23 18:08:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_social_profile_links`
--

CREATE TABLE `user_social_profile_links` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `facebook` varchar(191) DEFAULT NULL,
  `twitter` varchar(191) DEFAULT NULL,
  `linkedin` varchar(191) DEFAULT NULL,
  `behance` varchar(191) DEFAULT NULL,
  `youtube` varchar(191) DEFAULT NULL,
  `instagram` varchar(191) DEFAULT NULL,
  `dribble` varchar(191) DEFAULT NULL,
  `google_plus` varchar(191) DEFAULT NULL,
  `skype` varchar(191) DEFAULT NULL,
  `pinterest` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `activities_activity_type_id_foreign` (`activity_type_id`),
  ADD KEY `activities_contextable_type_contextable_id_index` (`contextable_type`,`contextable_id`),
  ADD KEY `activities_created_by_foreign` (`created_by`),
  ADD KEY `activities_status_id_foreign` (`status_id`);

--
-- Indexes for table `activity_collaborator`
--
ALTER TABLE `activity_collaborator`
  ADD PRIMARY KEY (`activity_id`,`user_id`),
  ADD KEY `activity_collaborator_user_id_foreign` (`user_id`);

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `activity_log_log_name_index` (`log_name`),
  ADD KEY `subject` (`subject_id`,`subject_type`),
  ADD KEY `causer` (`causer_id`,`causer_type`);

--
-- Indexes for table `activity_participant`
--
ALTER TABLE `activity_participant`
  ADD PRIMARY KEY (`activity_id`,`person_id`),
  ADD KEY `activity_participant_person_id_foreign` (`person_id`);

--
-- Indexes for table `activity_types`
--
ALTER TABLE `activity_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD UNIQUE KEY `cache_key_unique` (`key`);

--
-- Indexes for table `contact_types`
--
ALTER TABLE `contact_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `countries_code_unique` (`code`),
  ADD UNIQUE KEY `countries_name_unique` (`name`);

--
-- Indexes for table `custom_fields`
--
ALTER TABLE `custom_fields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `custom_fields_custom_field_type_id_foreign` (`custom_field_type_id`),
  ADD KEY `custom_fields_created_by_foreign` (`created_by`);

--
-- Indexes for table `custom_field_types`
--
ALTER TABLE `custom_field_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `custom_field_values`
--
ALTER TABLE `custom_field_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `custom_field_values_custom_field_id_foreign` (`custom_field_id`),
  ADD KEY `custom_field_values_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `deals`
--
ALTER TABLE `deals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deals_pipeline_id_foreign` (`pipeline_id`),
  ADD KEY `deals_stage_id_foreign` (`stage_id`),
  ADD KEY `deals_lost_reason_id_foreign` (`lost_reason_id`),
  ADD KEY `deals_status_id_foreign` (`status_id`),
  ADD KEY `deals_created_by_foreign` (`created_by`),
  ADD KEY `deals_owner_id_foreign` (`owner_id`);

--
-- Indexes for table `deal_people`
--
ALTER TABLE `deal_people`
  ADD KEY `deal_people_deal_id_foreign` (`deal_id`),
  ADD KEY `deal_people_person_id_foreign` (`person_id`);

--
-- Indexes for table `default_stages`
--
ALTER TABLE `default_stages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `default_stages_created_by_foreign` (`created_by`);

--
-- Indexes for table `discussions`
--
ALTER TABLE `discussions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `discussions_commentable_type_commentable_id_index` (`commentable_type`,`commentable_id`),
  ADD KEY `discussions_commented_by_foreign` (`commented_by`),
  ADD KEY `discussions_comment_id_of_reply_foreign` (`comment_id_of_reply`);

--
-- Indexes for table `emails`
--
ALTER TABLE `emails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `emails_contextable_type_contextable_id_index` (`contextable_type`,`contextable_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `events_status_id_foreign` (`status_id`),
  ADD KEY `events_created_by_foreign` (`created_by`),
  ADD KEY `events_contact_type_id_foreign` (`contact_type_id`),
  ADD KEY `events_contextable_type_contextable_id_index` (`contextable_type`,`contextable_id`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `expenses_expense_area_id_foreign` (`expense_area_id`),
  ADD KEY `expenses_created_by_foreign` (`created_by`);

--
-- Indexes for table `expense_areas`
--
ALTER TABLE `expense_areas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `expense_areas_created_by_foreign` (`created_by`);

--
-- Indexes for table `extended_notifications`
--
ALTER TABLE `extended_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `extended_notifications_user_id_foreign` (`user_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fileable_index` (`fileable_type`,`fileable_id`);

--
-- Indexes for table `followers`
--
ALTER TABLE `followers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `followers_person_id_foreign` (`person_id`),
  ADD KEY `followers_contextable_type_contextable_id_index` (`contextable_type`,`contextable_id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `invoices_deal_id_foreign` (`deal_id`),
  ADD KEY `invoices_status_id_foreign` (`status_id`),
  ADD KEY `invoices_owner_id_foreign` (`owner_id`),
  ADD KEY `invoices_created_by_foreign` (`created_by`),
  ADD KEY `invoices_tax_id_foreign` (`tax_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `lost_reasons`
--
ALTER TABLE `lost_reasons`
  ADD PRIMARY KEY (`id`),
  ADD KEY `lost_reasons_created_by_foreign` (`created_by`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notes_status_id_foreign` (`status_id`),
  ADD KEY `notes_created_by_foreign` (`created_by`),
  ADD KEY `notes_noteable_type_noteable_id_index` (`noteable_type`,`noteable_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification_audiences`
--
ALTER TABLE `notification_audiences`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notification_audiences_notification_setting_id_foreign` (`notification_setting_id`);

--
-- Indexes for table `notification_channels`
--
ALTER TABLE `notification_channels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification_events`
--
ALTER TABLE `notification_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notification_events_type_id_foreign` (`type_id`);

--
-- Indexes for table `notification_event_template`
--
ALTER TABLE `notification_event_template`
  ADD KEY `notification_event_template_notification_event_id_foreign` (`notification_event_id`),
  ADD KEY `notification_event_template_notification_template_id_foreign` (`notification_template_id`);

--
-- Indexes for table `notification_settings`
--
ALTER TABLE `notification_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notification_settings_notification_event_id_foreign` (`notification_event_id`),
  ADD KEY `notification_settings_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `notification_templates`
--
ALTER TABLE `notification_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organizations`
--
ALTER TABLE `organizations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `organizations_created_by_foreign` (`created_by`),
  ADD KEY `organizations_owner_id_foreign` (`owner_id`),
  ADD KEY `organizations_country_id_foreign` (`country_id`);

--
-- Indexes for table `participants`
--
ALTER TABLE `participants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `participants_deal_id_foreign` (`deal_id`),
  ADD KEY `participants_person_id_foreign` (`person_id`);

--
-- Indexes for table `password_histories`
--
ALTER TABLE `password_histories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `people`
--
ALTER TABLE `people`
  ADD PRIMARY KEY (`id`),
  ADD KEY `people_created_by_foreign` (`created_by`),
  ADD KEY `people_owner_id_foreign` (`owner_id`),
  ADD KEY `people_country_id_foreign` (`country_id`),
  ADD KEY `people_attach_login_user_id_foreign` (`attach_login_user_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permissions_type_id_foreign` (`type_id`);

--
-- Indexes for table `person_organization`
--
ALTER TABLE `person_organization`
  ADD KEY `person_organization_person_id_foreign` (`person_id`),
  ADD KEY `person_organization_organization_id_foreign` (`organization_id`);

--
-- Indexes for table `phones`
--
ALTER TABLE `phones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `phones_contextable_type_contextable_id_index` (`contextable_type`,`contextable_id`);

--
-- Indexes for table `phone_email_types`
--
ALTER TABLE `phone_email_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pipelines`
--
ALTER TABLE `pipelines`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pipelines_name_unique` (`name`),
  ADD KEY `pipelines_created_by_foreign` (`created_by`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `profiles_user_id_foreign` (`user_id`);

--
-- Indexes for table `proposals`
--
ALTER TABLE `proposals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `proposals_status_id_foreign` (`status_id`),
  ADD KEY `proposals_deal_id_foreign` (`deal_id`),
  ADD KEY `proposals_owner_id_foreign` (`owner_id`),
  ADD KEY `proposals_created_by_foreign` (`created_by`);

--
-- Indexes for table `revisions`
--
ALTER TABLE `revisions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `revisions_revisionable_id_revisionable_type_index` (`revisionable_id`,`revisionable_type`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `roles_type_id_foreign` (`type_id`),
  ADD KEY `roles_created_by_foreign` (`created_by`),
  ADD KEY `roles_name_index` (`name`);

--
-- Indexes for table `role_permission`
--
ALTER TABLE `role_permission`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_permission_role_id_foreign` (`role_id`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`user_id`,`role_id`),
  ADD KEY `role_user_role_id_foreign` (`role_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `settingable_index` (`settingable_type`,`settingable_id`);

--
-- Indexes for table `stages`
--
ALTER TABLE `stages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `stages_pipeline_id_foreign` (`pipeline_id`),
  ADD KEY `stages_created_by_foreign` (`created_by`);

--
-- Indexes for table `statuses`
--
ALTER TABLE `statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_filters`
--
ALTER TABLE `table_filters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `table_filters_user_id_foreign` (`user_id`);

--
-- Indexes for table `taggables`
--
ALTER TABLE `taggables`
  ADD UNIQUE KEY `taggables_tag_id_taggable_type_taggable_id_unique` (`tag_id`,`taggable_type`,`taggable_id`),
  ADD KEY `taggables_taggable_type_taggable_id_index` (`taggable_type`,`taggable_id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tags_name_unique` (`name`);

--
-- Indexes for table `taxes`
--
ALTER TABLE `taxes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `templates`
--
ALTER TABLE `templates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `templates_created_by_foreign` (`created_by`),
  ADD KEY `templates_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `types_alias_unique` (`alias`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_status_id_foreign` (`status_id`),
  ADD KEY `users_created_by_foreign` (`created_by`);

--
-- Indexes for table `user_social_profile_links`
--
ALTER TABLE `user_social_profile_links`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_social_profile_links_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `activity_types`
--
ALTER TABLE `activity_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contact_types`
--
ALTER TABLE `contact_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=244;

--
-- AUTO_INCREMENT for table `custom_fields`
--
ALTER TABLE `custom_fields`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `custom_field_types`
--
ALTER TABLE `custom_field_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `custom_field_values`
--
ALTER TABLE `custom_field_values`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deals`
--
ALTER TABLE `deals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `default_stages`
--
ALTER TABLE `default_stages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `discussions`
--
ALTER TABLE `discussions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `emails`
--
ALTER TABLE `emails`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `expense_areas`
--
ALTER TABLE `expense_areas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `extended_notifications`
--
ALTER TABLE `extended_notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `followers`
--
ALTER TABLE `followers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lost_reasons`
--
ALTER TABLE `lost_reasons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notification_audiences`
--
ALTER TABLE `notification_audiences`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `notification_channels`
--
ALTER TABLE `notification_channels`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notification_events`
--
ALTER TABLE `notification_events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `notification_settings`
--
ALTER TABLE `notification_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `notification_templates`
--
ALTER TABLE `notification_templates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `organizations`
--
ALTER TABLE `organizations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `participants`
--
ALTER TABLE `participants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `password_histories`
--
ALTER TABLE `password_histories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `people`
--
ALTER TABLE `people`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;

--
-- AUTO_INCREMENT for table `phones`
--
ALTER TABLE `phones`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `phone_email_types`
--
ALTER TABLE `phone_email_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pipelines`
--
ALTER TABLE `pipelines`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `proposals`
--
ALTER TABLE `proposals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `revisions`
--
ALTER TABLE `revisions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `stages`
--
ALTER TABLE `stages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `statuses`
--
ALTER TABLE `statuses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `table_filters`
--
ALTER TABLE `table_filters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `taxes`
--
ALTER TABLE `taxes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `templates`
--
ALTER TABLE `templates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `types`
--
ALTER TABLE `types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_social_profile_links`
--
ALTER TABLE `user_social_profile_links`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activities`
--
ALTER TABLE `activities`
  ADD CONSTRAINT `activities_activity_type_id_foreign` FOREIGN KEY (`activity_type_id`) REFERENCES `activity_types` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `activities_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `activities_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `activity_collaborator`
--
ALTER TABLE `activity_collaborator`
  ADD CONSTRAINT `activity_collaborator_activity_id_foreign` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `activity_collaborator_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `activity_participant`
--
ALTER TABLE `activity_participant`
  ADD CONSTRAINT `activity_participant_activity_id_foreign` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `activity_participant_person_id_foreign` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `custom_fields`
--
ALTER TABLE `custom_fields`
  ADD CONSTRAINT `custom_fields_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `custom_fields_custom_field_type_id_foreign` FOREIGN KEY (`custom_field_type_id`) REFERENCES `custom_field_types` (`id`);

--
-- Constraints for table `custom_field_values`
--
ALTER TABLE `custom_field_values`
  ADD CONSTRAINT `custom_field_values_custom_field_id_foreign` FOREIGN KEY (`custom_field_id`) REFERENCES `custom_fields` (`id`),
  ADD CONSTRAINT `custom_field_values_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `deals`
--
ALTER TABLE `deals`
  ADD CONSTRAINT `deals_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `deals_lost_reason_id_foreign` FOREIGN KEY (`lost_reason_id`) REFERENCES `lost_reasons` (`id`),
  ADD CONSTRAINT `deals_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `deals_pipeline_id_foreign` FOREIGN KEY (`pipeline_id`) REFERENCES `pipelines` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `deals_stage_id_foreign` FOREIGN KEY (`stage_id`) REFERENCES `stages` (`id`),
  ADD CONSTRAINT `deals_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `deal_people`
--
ALTER TABLE `deal_people`
  ADD CONSTRAINT `deal_people_deal_id_foreign` FOREIGN KEY (`deal_id`) REFERENCES `deals` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `deal_people_person_id_foreign` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `default_stages`
--
ALTER TABLE `default_stages`
  ADD CONSTRAINT `default_stages_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `discussions`
--
ALTER TABLE `discussions`
  ADD CONSTRAINT `discussions_comment_id_of_reply_foreign` FOREIGN KEY (`comment_id_of_reply`) REFERENCES `discussions` (`id`),
  ADD CONSTRAINT `discussions_commented_by_foreign` FOREIGN KEY (`commented_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_contact_type_id_foreign` FOREIGN KEY (`contact_type_id`) REFERENCES `contact_types` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `events_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `events_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `expenses`
--
ALTER TABLE `expenses`
  ADD CONSTRAINT `expenses_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `expenses_expense_area_id_foreign` FOREIGN KEY (`expense_area_id`) REFERENCES `expense_areas` (`id`);

--
-- Constraints for table `expense_areas`
--
ALTER TABLE `expense_areas`
  ADD CONSTRAINT `expense_areas_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `extended_notifications`
--
ALTER TABLE `extended_notifications`
  ADD CONSTRAINT `extended_notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `followers`
--
ALTER TABLE `followers`
  ADD CONSTRAINT `followers_person_id_foreign` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `invoices_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `invoices_deal_id_foreign` FOREIGN KEY (`deal_id`) REFERENCES `deals` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `invoices_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `invoices_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `invoices_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `taxes` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `lost_reasons`
--
ALTER TABLE `lost_reasons`
  ADD CONSTRAINT `lost_reasons_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `notes`
--
ALTER TABLE `notes`
  ADD CONSTRAINT `notes_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `notes_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `notification_audiences`
--
ALTER TABLE `notification_audiences`
  ADD CONSTRAINT `notification_audiences_notification_setting_id_foreign` FOREIGN KEY (`notification_setting_id`) REFERENCES `notification_settings` (`id`);

--
-- Constraints for table `notification_events`
--
ALTER TABLE `notification_events`
  ADD CONSTRAINT `notification_events_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `types` (`id`);

--
-- Constraints for table `notification_event_template`
--
ALTER TABLE `notification_event_template`
  ADD CONSTRAINT `notification_event_template_notification_event_id_foreign` FOREIGN KEY (`notification_event_id`) REFERENCES `notification_events` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `notification_event_template_notification_template_id_foreign` FOREIGN KEY (`notification_template_id`) REFERENCES `notification_templates` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notification_settings`
--
ALTER TABLE `notification_settings`
  ADD CONSTRAINT `notification_settings_notification_event_id_foreign` FOREIGN KEY (`notification_event_id`) REFERENCES `notification_events` (`id`),
  ADD CONSTRAINT `notification_settings_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `organizations`
--
ALTER TABLE `organizations`
  ADD CONSTRAINT `organizations_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `organizations_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `organizations_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `participants`
--
ALTER TABLE `participants`
  ADD CONSTRAINT `participants_deal_id_foreign` FOREIGN KEY (`deal_id`) REFERENCES `deals` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `participants_person_id_foreign` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `people`
--
ALTER TABLE `people`
  ADD CONSTRAINT `people_attach_login_user_id_foreign` FOREIGN KEY (`attach_login_user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `people_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `people_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `people_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `permissions`
--
ALTER TABLE `permissions`
  ADD CONSTRAINT `permissions_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `types` (`id`) ON DELETE NO ACTION;

--
-- Constraints for table `person_organization`
--
ALTER TABLE `person_organization`
  ADD CONSTRAINT `person_organization_organization_id_foreign` FOREIGN KEY (`organization_id`) REFERENCES `organizations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `person_organization_person_id_foreign` FOREIGN KEY (`person_id`) REFERENCES `people` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `pipelines`
--
ALTER TABLE `pipelines`
  ADD CONSTRAINT `pipelines_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `profiles`
--
ALTER TABLE `profiles`
  ADD CONSTRAINT `profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `proposals`
--
ALTER TABLE `proposals`
  ADD CONSTRAINT `proposals_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `proposals_deal_id_foreign` FOREIGN KEY (`deal_id`) REFERENCES `deals` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `proposals_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `proposals_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `roles`
--
ALTER TABLE `roles`
  ADD CONSTRAINT `roles_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `roles_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `types` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `role_permission`
--
ALTER TABLE `role_permission`
  ADD CONSTRAINT `role_permission_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_permission_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `stages`
--
ALTER TABLE `stages`
  ADD CONSTRAINT `stages_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `stages_pipeline_id_foreign` FOREIGN KEY (`pipeline_id`) REFERENCES `pipelines` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `table_filters`
--
ALTER TABLE `table_filters`
  ADD CONSTRAINT `table_filters_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `taggables`
--
ALTER TABLE `taggables`
  ADD CONSTRAINT `taggables_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `templates`
--
ALTER TABLE `templates`
  ADD CONSTRAINT `templates_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `templates_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `users_status_id_foreign` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_social_profile_links`
--
ALTER TABLE `user_social_profile_links`
  ADD CONSTRAINT `user_social_profile_links_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
